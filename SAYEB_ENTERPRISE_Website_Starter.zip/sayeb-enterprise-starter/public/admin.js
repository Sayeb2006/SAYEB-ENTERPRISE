const KEY = "sayebEnterpriseDemoEnquiries";
const $ = id => document.getElementById(id);
function load(){ try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return []} }
function save(items){localStorage.setItem(KEY,JSON.stringify(items));render()}
function render(){
 const items=load(); $("totalCount").textContent=items.length;
 $("enquiryList").innerHTML=items.length?items.map(x=>`<div class="enquiry-item"><div><b>${escapeHtml(x.name)}</b><small>${escapeHtml(x.service)}${x.note?" · "+escapeHtml(x.note):""}</small></div><small>${new Date(x.created).toLocaleString()}</small></div>`).join(""):'<p class="empty">No demo enquiries yet.</p>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("enquiryForm").addEventListener("submit",e=>{e.preventDefault();const items=load();items.unshift({name:$("customerName").value.trim(),service:$("serviceName").value.trim(),note:$("contactNote").value.trim(),created:new Date().toISOString()});save(items);e.target.reset()});
$("clearBtn").addEventListener("click",()=>{if(confirm("Delete all demo enquiries stored in this browser?")){localStorage.removeItem(KEY);render()}});
render();
