const services = [
  ["◎","EPFO / PF Services","UAN search and activation, KYC guidance, e-Nomination, PF claims, transfer and passbook assistance."],
  ["▣","Udyam Registration","Assistance with MSME / Udyam registration and related online application steps."],
  ["⌂","AEPS & Banking Services","Assistance with supported Aadhaar-enabled and banking services, subject to provider availability."],
  ["✈","Travel & Ticket Booking","Railway, flight and bus ticket booking assistance. Fares and availability are confirmed at booking."],
  ["▤","Printing & Cyber Cafe","Online forms, document printing, scanning, photocopying and general internet services."],
  ["＋","All Online Services","Enquire about other government, business and digital services offered at the centre."]
];
const grid = document.getElementById("serviceGrid");
grid.innerHTML = services.map(([icon,title,desc]) => `<article class="service-card"><div class="service-icon">${icon}</div><h3>${title}</h3><p>${desc}</p><button type="button" data-service="${title}">Enquire about this ↗</button></article>`).join("");
grid.addEventListener("click", e => {
  const btn = e.target.closest("button[data-service]");
  if (!btn) return;
  const msg = `Hello SAYEB ENTERPRISE, I would like to enquire about ${btn.dataset.service}. Please share the required documents, fees and process.`;
  window.open(`https://wa.me/919395748814?text=${encodeURIComponent(msg)}`, "_blank", "noopener");
});
document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("menuToggle").addEventListener("click", () => document.getElementById("nav").classList.toggle("open"));
